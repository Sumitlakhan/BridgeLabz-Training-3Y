$(function () {
  // Append a new post at the bottom of the list.
  $("#addPost").on("click", function () {
    const title = $("#postTitle").val().trim();
    if (!title) return alert("Please enter a post title.");
    $("#posts").append(
      $("<article>").append($("<h2>").text(title), $("<p>").text("New blog post content."))
    );
    $("#postTitle").val("");
    highlightKeywords();
  });

  // Prepend a featured post at the top.
  $("#featuredPost").on("click", function () {
    const $post = $("<article class='featured'></article>");
    $post.append($("<h2>").text("Featured: jQuery Tips"));
    $post.append($("<p>").text("A featured post added at the beginning."));
    $("#posts").prepend($post);
  });

  // Remove the final article.
  $("#removePost").on("click", function () {
    $("#posts article").last().remove();
  });

  // Place a tag before and after the first post using .before() and .after().
  $("#addTag").on("click", function () {
    const $first = $("#posts article").first();
    $first.before("<p class='tag'>Latest</p>");
    $first.after("<p class='tag'>Read more</p>");
  });

  // Highlight posts whose text contains selected keywords.
  function highlightKeywords() {
    $("#posts article").each(function () {
      const text = $(this).text().toLowerCase();
      $(this).toggleClass("featured", text.includes("javascript") || text.includes("jquery"));
    });
  }
  highlightKeywords();
});
