// Version 2 (the global jQuery/$ after the second script tag) handles modal and tooltips.
$(function () {
  $("#showModal").on("click", function () { $("#modal").fadeIn(); });
  $("#closeModal").on("click", function () { $("#modal").fadeOut(); });

  $(".widget").each(function () {
    const tip = $(this).attr("title");
    $(this).on("mouseenter", function () {
      $("<span class='tooltip'></span>").text(tip).appendTo(this);
    }).on("mouseleave", function () {
      $(this).find(".tooltip").remove();
    });
  });
});

// Version 1 was stored as jq3 using noConflict(true).
jq3(function () {
  const $slides = jq3(".slide");
  let index = 0;
  $slides.hide().eq(0).show();

  // Rotate the carousel every three seconds.
  setInterval(function () {
    $slides.eq(index).fadeOut(300, function () {
      index = (index + 1) % $slides.length;
      $slides.eq(index).fadeIn(300);
    });
  }, 3000);

  // Version 1 also handles active widget highlighting.
  jq3(".widget").on("click", function () {
    jq3(".widget").removeClass("active");
    jq3(this).addClass("active");
  });
});
