$(document).ready(function () {
  // Choose a greeting according to the visitor's local time.
  const hour = new Date().getHours();
  let greeting;

  if (hour < 12) greeting = "Good Morning!";
  else if (hour < 17) greeting = "Good Afternoon!";
  else greeting = "Good Evening!";

  $("#greeting").text(greeting);

  // Replace the greeting with a motivational quote.
  $("#changeGreeting").on("click", function () {
    $("#greeting").text("Believe in yourself. Every day is a new opportunity!");
  });

  // Toggle the welcome message's visibility.
  $("#toggleMessage").on("click", function () {
    $("#welcomeMessage").toggle();
  });

  // Display an alert when the greeting itself is clicked.
  $("#greeting").on("click", function () {
    alert("Welcome to our website!");
  });
});
