$(function () {
  const $courses = $("#courseList li");

  // Filter as the user types by using the keyup event.
  $("#search").on("keyup", function () {
    const query = $(this).val().trim().toLowerCase();
    let count = 0;

    $courses.each(function () {
      const originalText = $(this).text();
      const matches = originalText.toLowerCase().includes(query);

      // Show matching courses and hide the rest.
      $(this).toggle(matches);
      $(this).find("mark").each(function () { $(this).replaceWith($(this).text()); });

      if (matches && query) {
        const index = originalText.toLowerCase().indexOf(query);
        const before = originalText.slice(0, index);
        const matched = originalText.slice(index, index + query.length);
        const after = originalText.slice(index + query.length);
        $(this).html(
          $("<span>").text(before)[0].outerHTML +
          $("<mark>").text(matched)[0].outerHTML +
          $("<span>").text(after)[0].outerHTML
        );
      }

      if (matches) count++;
    });

    $("#count").text("Matched courses: " + count);
  });

  // Clear the search and restore every course.
  $("#clear").on("click", function () {
    $("#search").val("");
    $courses.show().each(function () {
      $(this).text($(this).text());
    });
    $("#count").text("Showing " + $courses.length + " courses");
  });
});
