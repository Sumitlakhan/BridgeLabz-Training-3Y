$(function () {
  // Click a question to show or hide its answer.
  $(".question").on("click", function () {
    $(this).next(".answer").slideToggle();
  });

  // Change question color while hovering.
  $(".question").hover(
    function () { $(this).css("color", "#0877c9"); },
    function () { $(this).css("color", ""); }
  );

  // Double-click any question to close every answer.
  $(".question").on("dblclick", function () {
    $(".answer").slideUp();
  });

  // Highlight the parent question while its answer input has focus.
  $(".answer input").on("focus", function () {
    $(this).closest(".faq-item").find(".question").css("background-color", "#fff1b8");
  });

  // Reset the question background when the input loses focus.
  $(".answer input").on("blur", function () {
    $(this).closest(".faq-item").find(".question").css("background-color", "");
  });
});
