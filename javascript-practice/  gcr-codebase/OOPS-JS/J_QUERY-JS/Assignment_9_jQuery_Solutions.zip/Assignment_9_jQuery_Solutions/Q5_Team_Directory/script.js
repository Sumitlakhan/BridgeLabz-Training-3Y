$(function () {
  // Highlight direct reports belonging to the clicked manager.
  $(".manager").on("click", function () {
    $(this).siblings(".reports").children(".employee").toggleClass("highlight");
  });

  // .next() displays the contact information next to an employee name.
  $(".employee").hover(
    function () { $(this).find(".contact").show(); },
    function () { $(this).find(".contact").hide(); }
  );

  // .children() selects the direct team container inside the department.
  $(".department-title").on("click", function () {
    $(this).parent().children(".team").find(".member").css("background-color", "#e5f4ff");
  });

  // Select one random employee and highlight that employee's siblings.
  $("#randomEmployee").on("click", function () {
    const $employees = $(".employee");
    $employees.removeClass("highlight");
    const randomIndex = Math.floor(Math.random() * $employees.length);
    const $chosen = $employees.eq(randomIndex);
    $chosen.siblings(".employee").addClass("highlight");
    $chosen.addClass("highlight");
  });

  // Use .parent() and .find() to collapse/expand all team members.
  $("#collapseTeam").on("click", function () {
    $(".department-title").parent().find(".team").toggle();
  });
});
