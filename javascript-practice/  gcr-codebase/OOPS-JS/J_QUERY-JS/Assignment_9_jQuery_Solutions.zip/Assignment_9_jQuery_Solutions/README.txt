# Assignment 9 – jQuery Solutions

This package contains 10 separate question folders. Each folder has:
- `index.html`
- `script.js`

## How to run
1. Extract this ZIP file.
2. Open any question folder in VS Code.
3. Open `index.html` in a browser (Live Server is recommended).
4. Keep an internet connection because the pages load jQuery from the official CDN.

Each question is independent. Q9 intentionally loads jQuery 3.7.1 and 2.2.4 to demonstrate `noConflict(true)`.
