$(function () {
  // Click a product card to highlight it; clicking its favorite button is handled separately.
  $(".product").on("click", function (event) {
    if ($(event.target).closest(".favorite").length) return;
    $(this).toggleClass("highlight");
    if ($(this).data("stock") === "no") alert("Sorry, this product is out of stock.");
  });

  // Reveal extra details while the pointer is over a product.
  $(".product").hover(
    function () { $(this).find(".details").stop(true, true).slideDown(150); },
    function () { $(this).find(".details").stop(true, true).slideUp(150); }
  );

  // Toggle the selected class and heart symbol.
  $(".favorite").on("click", function (event) {
    event.stopPropagation();
    $(this).toggleClass("selected");
    $(this).text($(this).hasClass("selected") ? "♥" : "♡");
  });
});
