$(function () {
  const $banners = $(".banner");
  let current = 0;

  $("#hide").on("click", function () { $banners.eq(0).hide(); });
  $("#show").on("click", function () { $banners.show(); });
  $("#slideUp").on("click", function () { $banners.slideUp(); });
  $("#slideDown").on("click", function () { $banners.slideDown(); });
  $("#fadeOut").on("click", function () { $banners.fadeOut(500); });
  $("#fadeIn").on("click", function () { $banners.fadeIn(500); });

  // Display one banner at a time, rotating every five seconds.
  $banners.hide().eq(0).show();
  setInterval(function () {
    $banners.eq(current).fadeOut(400, function () {
      current = (current + 1) % $banners.length;
      $banners.eq(current).fadeIn(400);
    });
  }, 5000);
});
