$(function () {
  // Attach delegated click handlers so they also work for dynamically added topics.
  $("#topics").on("click", ".subscribe", function () {
    $(this).closest("li").attr("data-subscribed", "true");
    $(this).text("Subscribed").prop("disabled", true);
    $("#message").text("Subscription enabled. Notifications are ON.");
  });

  $("#topics").on("click", ".remove", function () {
    const $item = $(this).closest("li");
    // Demonstrate .off() by detaching handlers from the selected item before removal.
    $item.off();
    $item.remove();
    $("#message").text("Subscription topic removed.");
  });

  $("#addTopic").on("click", function () {
    const topic = $("#newTopic").val().trim();
    if (!topic) {
      $("#message").text("Please enter a topic.");
      return;
    }
    // New topics inherit delegated .on() events from the list.
    $("#topics").append(`<li>${$("<div>").text(topic).html()} <button class="subscribe">Subscribe</button><button class="remove">Remove</button></li>`);
    $("#newTopic").val("");
    $("#message").text("New topic added.");
  });
});
