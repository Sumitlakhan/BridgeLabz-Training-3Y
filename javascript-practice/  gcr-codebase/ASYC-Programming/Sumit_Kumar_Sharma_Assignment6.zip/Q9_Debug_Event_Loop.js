// Assignment 6 - Q9
// Created by: Sumit Kumar Sharma
"use strict";

// Predicted output:
// Script start
// Script end
// Promise callback
// Timeout callback

console.log("Script start");

setTimeout(() => {
    console.log("Timeout callback");
}, 0);

Promise.resolve().then(() => {
    console.log("Promise callback");
});

console.log("Script end");

// Synchronous statements run first. Promise.then() is a microtask,
// and setTimeout() is a macrotask. Microtasks run before macrotasks.
