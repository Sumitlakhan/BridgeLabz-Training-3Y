// Assignment 6 - Q5
// Created by: Sumit Kumar Sharma
"use strict";

// Part 1: Nested callbacks (callback hell demonstration)
function runCallbackPipeline() {
    function stage(name, callback) {
        setTimeout(() => {
            console.log(name);
            callback();
        }, 1000);
    }

    console.log("Callback pipeline:");
    stage("Design", () => {
        stage("Build", () => {
            stage("Test", () => {
                stage("Deploy", () => {
                    stage("Celebrate", () => {
                        console.log("Callback pipeline completed.");
                        runAsyncPipeline();
                    });
                });
            });
        });
    });
}

// Part 2: Cleaner async/await version
function waitForStage(name) {
    return new Promise(resolve => {
        setTimeout(() => {
            console.log(name);
            resolve();
        }, 1000);
    });
}

async function runAsyncPipeline() {
    console.log("\nAsync/await pipeline:");
    await waitForStage("Design");
    await waitForStage("Build");
    await waitForStage("Test");
    await waitForStage("Deploy");
    await waitForStage("Celebrate");
    console.log("Async/await pipeline completed.");
}

// async/await makes asynchronous steps read from top to bottom and
// avoids deeply nested callback functions.
runCallbackPipeline();
