// Assignment 6 - Q10
// Created by: Sumit Kumar Sharma
"use strict";

function deliveryStep(stepMessage) {
    return new Promise((resolve, reject) => {
        const delay = 1000 + Math.random() * 1000;

        setTimeout(() => {
            if (Math.random() < 0.15) {
                reject(new Error(stepMessage + " failed"));
            } else {
                console.log(stepMessage);
                resolve();
            }
        }, delay);
    });
}

async function runPipeline() {
    console.log("Start Pipeline");

    try {
        await deliveryStep("Step 1: Order taken");
        await deliveryStep("Step 2: Food prepared");
        await deliveryStep("Step 3: Package ready");
        await deliveryStep("Step 4: Out for delivery");
        await deliveryStep("Delivery completed!");
    } catch (error) {
        console.log("Pipeline failed!");
        console.log("Reason:", error.message);
    }
}

runPipeline();

// Each await pauses this async function until its Promise settles.
// Other JavaScript work can continue while the timer is waiting.
