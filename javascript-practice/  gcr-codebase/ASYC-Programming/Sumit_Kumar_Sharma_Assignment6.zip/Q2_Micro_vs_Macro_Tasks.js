// Assignment 6 - Q2
// Created by: Sumit Kumar Sharma
"use strict";

console.log("Start");

setTimeout(() => {
    console.log("Timeout callback (macrotask)");
}, 0);

Promise.resolve().then(() => {
    console.log("Promise callback (microtask)");
});

console.log("Synchronous log");
console.log("End");

// Expected order:
// Start
// Synchronous log
// End
// Promise callback (microtask)
// Timeout callback (macrotask)
//
// JavaScript completes synchronous code first. Then it empties the
// microtask queue (Promises), before taking the setTimeout macrotask.
