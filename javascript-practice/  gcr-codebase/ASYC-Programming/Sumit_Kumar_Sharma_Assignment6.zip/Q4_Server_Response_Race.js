// Assignment 6 - Q4
// Created by: Sumit Kumar Sharma
"use strict";

function serverResponse(serverName, delay) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (Math.random() < 0.2) {
                reject(new Error(serverName + " failed"));
            } else {
                resolve(serverName + " responded");
            }
        }, delay);
    });
}

const serverA = serverResponse("Server A", 2000);
const serverB = serverResponse("Server B", 3000);

Promise.all([serverA, serverB])
    .then(() => console.log("Deployment completed for all servers"))
    .catch(error => console.log("Deployment error:", error.message));

// Create separate promises for race because Promise.all may already have
// observed a rejection; each call represents a new server request.
Promise.race([
    serverResponse("Server A", 2000),
    serverResponse("Server B", 3000)
])
    .then(result => console.log("Fastest response:", result))
    .catch(error => console.log("Race error:", error.message));
