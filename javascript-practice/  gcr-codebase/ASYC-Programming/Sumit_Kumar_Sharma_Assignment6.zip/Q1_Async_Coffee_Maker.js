// Assignment 6 - Q1
// Created by: Sumit Kumar Sharma
"use strict";

function waitStep(stepName) {
    return new Promise((resolve, reject) => {
        const delay = 1000 + Math.random() * 1000;

        setTimeout(() => {
            if (Math.random() < 0.2) {
                reject(new Error(stepName + " failed."));
            } else {
                console.log(stepName + " completed.");
                resolve();
            }
        }, delay);
    });
}

waitStep("Boiling water")
    .then(() => waitStep("Brewing coffee"))
    .then(() => waitStep("Pouring coffee into cup"))
    .then(() => console.log("Coffee ready for the team!"))
    .catch(error => console.log("Coffee process error:", error.message));
