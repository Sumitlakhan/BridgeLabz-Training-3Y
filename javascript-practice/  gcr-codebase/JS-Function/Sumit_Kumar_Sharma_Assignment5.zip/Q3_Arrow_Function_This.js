"use strict";
// Created by: Sumit Kumar Sharma

let user = {
    name: "Sumit",
    showName: () => {
        console.log(this.name);
    }
};

user.showName(); // Arrow function does not have its own this.

// Fix using a normal function:
let fixedUser = {
    name: "Sumit",
    showName: function () {
        console.log(this.name);
    }
};

fixedUser.showName();
