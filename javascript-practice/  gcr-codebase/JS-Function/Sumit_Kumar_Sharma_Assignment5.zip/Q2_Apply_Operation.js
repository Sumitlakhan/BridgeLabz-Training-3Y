"use strict";
// Created by: Sumit Kumar Sharma

function applyOperation(numbers, operation) {
    let result = [];
    for (let i = 0; i < numbers.length; i++) {
        result.push(operation(numbers[i]));
    }
    return result;
}

let numbers = [1, 2, 3, 4];

let doubled = applyOperation(numbers, num => num * 2);
let squared = applyOperation(numbers, num => num * num);

console.log("Doubled:", doubled);
console.log("Squared:", squared);
