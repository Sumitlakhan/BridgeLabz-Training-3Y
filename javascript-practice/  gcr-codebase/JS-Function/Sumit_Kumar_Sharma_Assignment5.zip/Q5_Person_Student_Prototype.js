"use strict";
// Created by: Sumit Kumar Sharma

function Person(name) {
    this.name = name;
}

Person.prototype.showName = function () {
    console.log("Name:", this.name);
};

function Student(name, branch) {
    Person.call(this, name);
    this.branch = branch;
}

Student.prototype = Object.create(Person.prototype);
Student.prototype.constructor = Student;

Student.prototype.showBranch = function () {
    console.log("Branch:", this.branch);
};

let student = new Student("Sumit", "CSE");

student.showName();
student.showBranch();

console.log(student instanceof Student);
console.log(student instanceof Person);
