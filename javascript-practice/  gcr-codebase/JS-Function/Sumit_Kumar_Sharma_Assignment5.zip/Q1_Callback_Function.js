"use strict";
// Created by: Sumit Kumar Sharma

function showEndMessage() {
    console.log("Welcome to the course!");
}

function greetUser(name, callback) {
    console.log("Hello " + name);
    callback();
}

greetUser("Sumit Kumar Sharma", showEndMessage);
