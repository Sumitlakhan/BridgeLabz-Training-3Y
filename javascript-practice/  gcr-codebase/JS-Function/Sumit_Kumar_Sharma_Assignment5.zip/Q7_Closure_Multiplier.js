"use strict";
// Created by: Sumit Kumar Sharma

function makeMultiplier(multiplier) {
    return function (number) {
        return number * multiplier;
    };
}

const triple = makeMultiplier(3);
console.log(triple(5)); // 15

// Closure: inner function remembers multiplier from outer function.
