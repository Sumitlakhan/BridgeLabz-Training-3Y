"use strict";
// Created by: Sumit Kumar Sharma

// Constructor/prototype version
function Person(name) {
    this.name = name;
}
Person.prototype.showName = function () {
    console.log("Prototype Name:", this.name);
};

function Student(name, branch) {
    Person.call(this, name);
    this.branch = branch;
}
Student.prototype = Object.create(Person.prototype);
Student.prototype.constructor = Student;
Student.prototype.showBranch = function () {
    console.log("Prototype Branch:", this.branch);
};

// ES6 class version
class PersonClass {
    constructor(name) {
        this.name = name;
    }
    showName() {
        console.log("Class Name:", this.name);
    }
}

class StudentClass extends PersonClass {
    constructor(name, branch) {
        super(name);
        this.branch = branch;
    }
    showBranch() {
        console.log("Class Branch:", this.branch);
    }
}

let student1 = new Student("Sumit", "CSE");
let student2 = new StudentClass("Sumit", "CSE");

student1.showName();
student1.showBranch();

student2.showName();
student2.showBranch();
