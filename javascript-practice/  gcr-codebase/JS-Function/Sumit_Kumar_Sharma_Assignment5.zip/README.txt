Assignment 5 - JavaScript Functions
Created by: Sumit Kumar Sharma
Nine separate JS files for Q1-Q9. Run using: node filename.js
